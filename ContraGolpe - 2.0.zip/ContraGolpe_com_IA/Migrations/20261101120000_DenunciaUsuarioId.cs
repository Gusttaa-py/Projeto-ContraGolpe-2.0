﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using WebApplication1.Data;

#nullable disable

namespace WebApplication1.Migrations
{
    /// <summary>Guarda quem registrou cada denúncia (permite restringir a exclusão ao autor).</summary>
    [DbContext(typeof(AppDbContext))]
    [Migration("20261101120000_DenunciaUsuarioId")]
    public partial class DenunciaUsuarioId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "UsuarioId",
                table: "Denuncias",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UsuarioId",
                table: "Denuncias");
        }
    }
}
