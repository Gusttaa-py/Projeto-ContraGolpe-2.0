using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace WebApplication1.Services
{
    public enum NivelRisco { Baixo, Medio, Alto }

    public class SinalDetectado
    {
        public string Descricao { get; set; } = "";
        public int Pontos { get; set; }
    }

    public class ResultadoAnalise
    {
        public int Pontuacao { get; set; }                 // 0 a 100
        public NivelRisco Nivel { get; set; }
        public string TipoProvavel { get; set; } = "Não identificado";
        public List<SinalDetectado> Sinais { get; set; } = new();
        public List<string> Recomendacoes { get; set; } = new();
    }

    public interface IAnalisadorGolpeService
    {
        ResultadoAnalise Analisar(string mensagem);
    }

    /// <summary>
    /// "IA simples" baseada em regras ponderadas (sistema especialista).
    /// Cada sinal de golpe encontrado soma pontos; a soma vira um nível de risco.
    /// Tambem estima o tipo de golpe mais provavel pela contagem de palavras-chave.
    /// </summary>
    public class AnalisadorGolpeService : IAnalisadorGolpeService
    {
        // Regras: (descricao, pontos, padrao regex aplicado ao texto normalizado)
        private static readonly (string Descricao, int Pontos, Regex Padrao)[] Regras =
        {
            ("Cria urgência ou ameaça de prazo (\"urgente\", \"últimas horas\", \"imediatamente\")", 20,
                R(@"\b(urgente|urgencia|imediatamente|ultimas horas|ultimo aviso|hoje mesmo|expira|prazo final|agora mesmo)\b")),

            ("Ameaça bloquear ou cancelar conta, cartão ou serviço", 20,
                R(@"\b(bloquead[oa]|bloqueio|suspens[oa]|suspensao|cancelad[oa]|cancelamento|encerrad[oa]|desativad[oa])\b")),

            ("Pede dados sensíveis (senha, CPF, cartão, código, token)", 30,
                R(@"\b(senha|cpf|cvv|token|codigo de verificacao|codigo de seguranca|numero do cartao|dados bancarios|dados do cartao)\b")),

            ("Pede transferência, Pix ou depósito", 20,
                R(@"\b((faca|fazer|envie|enviar|mande|mandar|manda|me ajuda com) (um |o |uma )?(pix|transferencia)|transfira|deposite|pague agora|taxa de liberacao|taxa para liberar)\b")),

            ("Promete prêmio, dinheiro fácil ou ganho garantido", 25,
                R(@"\b(voce ganhou|parabens|premio|sorteio|ganhe dinheiro|lucro garantido|renda extra|investimento garantido|heranca|restituicao)\b")),

            ("Finge ser banco, órgão público ou empresa conhecida", 15,
                R(@"\b(banco|caixa economica|receita federal|inss|detran|serasa|correios|policia federal|central de seguranca|setor de fraudes|gerente)\b")),

            ("Pede para clicar em link ou baixar arquivo/aplicativo", 15,
                R(@"\b(clique|acesse o link|acesse agora|baixe|instale|atualize seu aplicativo|confirme seus dados)\b")),

            ("Usa o discurso do \"familiar com número novo\" ou pedido de ajuda financeira", 25,
                R(@"\b(mudei de numero|numero novo|esse e meu novo|perdi meu celular|me ajuda|preciso de um favor)\b")),

            ("Pede sigilo ou pressiona para não falar com ninguém", 20,
                R(@"\b(nao (conte|conta|fale|avise|diga)|sigilo|segredo)\b")),
        };

        // Palavras-chave para estimar o tipo de golpe (alinhado as categorias do cadastro).
        private static readonly Dictionary<string, string[]> Tipos = new()
        {
            ["Pix"] = new[] { "pix", "chave pix", "transferencia", "comprovante" },
            ["WhatsApp"] = new[] { "whatsapp", "numero novo", "mudei de numero", "perdi meu celular", "codigo de verificacao" },
            ["Phishing"] = new[] { "clique", "link", "senha", "confirme seus dados", "atualize", "acesso" },
            ["Boleto"] = new[] { "boleto", "codigo de barras", "fatura", "segunda via" },
            ["Falso prêmio"] = new[] { "voce ganhou", "premio", "sorteio", "parabens", "brinde" },
            ["Falsa central"] = new[] { "central de seguranca", "setor de fraudes", "gerente", "banco", "cartao" },
        };

        private static Regex R(string padrao) =>
            new(padrao, RegexOptions.IgnoreCase | RegexOptions.Compiled);

        // Encurtadores e dominios/TLDs frequentemente usados em golpes.
        private static readonly string[] Encurtadores =
            { "bit.ly", "tinyurl.com", "t.co", "cutt.ly", "is.gd", "rb.gy", "shorturl.at", "ow.ly" };

        private static readonly string[] TldsSuspeitos =
            { ".xyz", ".top", ".click", ".icu", ".live", ".shop", ".online", ".site", ".cfd" };

        private static readonly Regex RegexUrl =
            new(@"(https?://[^\s]+|www\.[^\s]+|\b[a-z0-9-]+(\.[a-z0-9-]+)+/[^\s]*)",
                RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public ResultadoAnalise Analisar(string mensagem)
        {
            var resultado = new ResultadoAnalise();

            if (string.IsNullOrWhiteSpace(mensagem))
            {
                resultado.Nivel = NivelRisco.Baixo;
                return resultado;
            }

            var texto = Normalizar(mensagem);
            int total = 0;

            // 1) Regras de linguagem
            foreach (var regra in Regras)
            {
                if (regra.Padrao.IsMatch(texto))
                {
                    total += regra.Pontos;
                    resultado.Sinais.Add(new SinalDetectado { Descricao = regra.Descricao, Pontos = regra.Pontos });
                }
            }

            // 2) Analise de links
            foreach (Match m in RegexUrl.Matches(mensagem))
            {
                var url = m.Value.ToLowerInvariant().TrimEnd('.', ',', ')', '!');

                if (Encurtadores.Any(e => url.Contains(e)))
                {
                    total += 20;
                    resultado.Sinais.Add(new SinalDetectado
                    {
                        Descricao = $"Link encurtado esconde o destino real ({m.Value})",
                        Pontos = 20
                    });
                }
                else if (TldsSuspeitos.Any(t => Regex.IsMatch(url, Regex.Escape(t) + @"(/|$|\?)")))
                {
                    total += 15;
                    resultado.Sinais.Add(new SinalDetectado
                    {
                        Descricao = $"Link com domínio pouco comum em golpes ({m.Value})",
                        Pontos = 15
                    });
                }
                else if (Regex.IsMatch(url, @"https?://\d{1,3}(\.\d{1,3}){3}"))
                {
                    total += 25;
                    resultado.Sinais.Add(new SinalDetectado
                    {
                        Descricao = $"Link usa endereço IP em vez de nome de site ({m.Value})",
                        Pontos = 25
                    });
                }
                else
                {
                    total += 5;
                    resultado.Sinais.Add(new SinalDetectado
                    {
                        Descricao = $"A mensagem contém um link — confira o endereço antes de abrir ({m.Value})",
                        Pontos = 5
                    });
                }
            }

            // 3) Excesso de maiusculas ou de exclamacoes
            var letras = mensagem.Count(char.IsLetter);
            if (letras >= 20)
            {
                var proporcaoMaiusculas = (double)mensagem.Count(char.IsUpper) / letras;
                if (proporcaoMaiusculas > 0.5)
                {
                    total += 10;
                    resultado.Sinais.Add(new SinalDetectado { Descricao = "Texto quase todo em MAIÚSCULAS, típico de mensagens alarmistas", Pontos = 10 });
                }
            }
            if (mensagem.Count(c => c == '!') >= 3)
            {
                total += 5;
                resultado.Sinais.Add(new SinalDetectado { Descricao = "Muitos pontos de exclamação", Pontos = 5 });
            }

            // 4) Pontuacao final e nivel
            resultado.Pontuacao = Math.Clamp(total, 0, 100);
            resultado.Nivel = resultado.Pontuacao switch
            {
                >= 60 => NivelRisco.Alto,
                >= 30 => NivelRisco.Medio,
                _ => NivelRisco.Baixo
            };

            // 5) Tipo provavel (maior numero de palavras-chave encontradas)
            var melhor = Tipos
                .Select(t => new { Tipo = t.Key, Acertos = t.Value.Count(p => texto.Contains(p)) })
                .OrderByDescending(x => x.Acertos)
                .First();
            if (melhor.Acertos > 0 && resultado.Pontuacao >= 30)
                resultado.TipoProvavel = melhor.Tipo;

            // 6) Recomendacoes
            resultado.Recomendacoes = GerarRecomendacoes(resultado);
            return resultado;
        }

        private static List<string> GerarRecomendacoes(ResultadoAnalise r)
        {
            var lista = new List<string>();

            if (r.Nivel == NivelRisco.Alto)
            {
                lista.Add("Não clique em links, não baixe arquivos e não responda à mensagem.");
                lista.Add("Nunca informe senhas, códigos recebidos por SMS/WhatsApp ou dados do cartão.");
                lista.Add("Entre em contato com a instituição pelos canais oficiais (site ou telefone do verso do cartão).");
                lista.Add("Registre uma denúncia no ContraGolpe para alertar outras pessoas.");
            }
            else if (r.Nivel == NivelRisco.Medio)
            {
                lista.Add("Desconfie: confirme a informação por outro canal antes de agir.");
                lista.Add("Se for alguém conhecido, ligue para o número que você já tinha salvo.");
                lista.Add("Confira o endereço completo de qualquer link antes de abrir.");
            }
            else
            {
                lista.Add("Nenhum sinal forte de golpe foi encontrado, mas a análise automática não é infalível.");
                lista.Add("Mesmo assim, nunca compartilhe senhas ou códigos de verificação.");
            }

            if (r.TipoProvavel == "Pix")
                lista.Add("Antes de fazer um Pix, confirme o nome do destinatário que aparece no app do seu banco.");
            if (r.TipoProvavel == "WhatsApp")
                lista.Add("Ative a verificação em duas etapas do WhatsApp e nunca repasse o código de 6 dígitos.");
            if (r.TipoProvavel == "Boleto")
                lista.Add("Confira se o beneficiário do boleto é quem você esperava antes de pagar.");

            return lista;
        }

        // Minusculas, sem acentos, espacos colapsados.
        private static string Normalizar(string texto)
        {
            var decomposto = texto.ToLowerInvariant().Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder(decomposto.Length);
            foreach (var c in decomposto)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            }
            return Regex.Replace(sb.ToString().Normalize(NormalizationForm.FormC), @"\s+", " ");
        }
    }
}
