namespace WebApplication1.Services
{
    /// <summary>
    /// Pasta onde ficam as fotos de perfil enviadas pelos usuários.
    /// Fica FORA da pasta do projeto, para as fotos não sumirem quando o projeto é atualizado ou trocado
    /// (o banco guarda só o nome do arquivo).
    /// </summary>
    public sealed class ArmazenamentoAvatares
    {
        public string Pasta { get; }

        public ArmazenamentoAvatares(string pasta)
        {
            Pasta = pasta;
        }
    }
}
