using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace WebApplication1.Services
{
    public class ChatMensagem
    {
        public string Papel { get; set; } = "user";   // "user" ou "assistant"
        public string Texto { get; set; } = "";
    }

    public class ChatResposta
    {
        public string Texto { get; set; } = "";
        public bool UsouIA { get; set; }               // true = modelo de linguagem; false = respostas prontas
    }

    public interface IChatbotService
    {
        Task<ChatResposta> ResponderAsync(IReadOnlyList<ChatMensagem> conversa);
    }

    /// <summary>
    /// Assistente rápido do ContraGolpe: respostas prontas por palavras-chave, sem login, sem internet e sem chave de API.
    /// Reaproveita o analisador de mensagens quando o texto parece suspeito.
    /// (A conversa livre com IA generativa fica no ChatController / GeminiService.)
    /// </summary>
    public class ChatbotService : IChatbotService
    {
        private readonly IAnalisadorGolpeService _analisador;

        public ChatbotService(IAnalisadorGolpeService analisador)
        {
            _analisador = analisador;
        }

        public Task<ChatResposta> ResponderAsync(IReadOnlyList<ChatMensagem> conversa)
        {
            var ultima = conversa.LastOrDefault(m => m.Papel == "user")?.Texto ?? "";
            return Task.FromResult(new ChatResposta { Texto = RespostaPronta(ultima), UsouIA = false });
        }

        // ── Modo simples: respostas prontas ───────────────

        private static Regex R(string padrao) =>
            new(padrao, RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private static readonly (Regex Padrao, string Resposta)[] Intencoes =
        {
            (R(@"\b(fui vitima|cai num golpe|cai em golpe|fui enganad\w*|fui golpead\w*|perdi dinheiro|me roubaram|clonaram|clonado|invadiram|hackearam|ja fiz o pix|ja transferi|ja paguei)\b"),
             "Sinto muito que isso tenha acontecido. Aja rápido:\n" +
             "1) Fale com o seu banco agora, pelo app ou pelo telefone oficial, e peça a contestação. Para Pix, existe o pedido de devolução (MED), então avise o quanto antes.\n" +
             "2) Registre um boletim de ocorrência (muitos estados têm delegacia online).\n" +
             "3) Troque as senhas das contas afetadas e ative a verificação em duas etapas.\n" +
             "4) Guarde prints e comprovantes e registre a denúncia no ContraGolpe para alertar outras pessoas."),

            (R(@"\b(namoro|namorado|namorada|romance|relacionamento|apaixonad\w*|golpe do amor|conheci (um|uma) (homem|mulher|pessoa))\b"),
             "Golpe do amor: um perfil falso cria afeto por semanas e depois pede dinheiro para uma emergência, viagem ou investimento.\n" +
             "Sinais: não faz chamada de vídeo, pede segredo e sempre surge uma urgência financeira. Nunca envie dinheiro para quem você não conhece pessoalmente."),

            (R(@"\b(voz clonada|clonaram a voz|deepfake|inteligencia artificial|audio falso|video falso|voz de (um )?(parente|filho|filha|mae|pai|chefe))\b"),
             "Golpistas usam inteligência artificial para imitar a voz ou o rosto de parentes, chefes e celebridades.\n" +
             "Proteção: desligue e ligue de volta para o número que você já tem, faça uma pergunta que só a pessoa saberia, combine uma palavra-código com a família e desconfie de pedido urgente de dinheiro."),

            (R(@"\b(qr ?code|qrcode)\b"),
             "Golpe do QR Code: o código falso é colado sobre o verdadeiro (cartaz, estacionamento, cardápio) ou enviado por e-mail e leva a uma página falsa ou a um Pix para o golpista.\n" +
             "Dicas: confira se o adesivo está sobreposto, veja o endereço antes de abrir e nunca informe senha ou código depois de escanear."),

            (R(@"\b(multa|pedagio|ipva|detran|cnh|taxa pendente)\b"),
             "Golpe da falsa multa ou pedágio: SMS ou e-mail cobra uma taxa pendente com link para pagamento falso e ameaça bloquear a CNH ou o veículo.\n" +
             "Consulte débitos apenas no site ou app oficial do órgão, digitando você mesmo o endereço."),

            (R(@"\b(inss|aposentad\w*|consignado|beneficio)\b"),
             "Golpe do falso INSS ou consignado: ligam ou mandam mensagem sobre benefício bloqueado, restituição ou empréstimo consignado e pedem dados, taxa ou senha do Meu INSS.\n" +
             "Use somente os canais oficiais, nunca informe senhas e não pague taxa para liberar valores."),

            (R(@"\b(sequestro|sequestraram|resgate|advogado|processo judicial)\b"),
             "Falso sequestro ou falso advogado: a ligação tem choro, gritos ou dados de um processo para pressionar por Pix imediato.\n" +
             "Desligue, ligue direto para o familiar ou para o seu advogado e nunca pague sob pressão."),

            (R(@"\b(vaquinha|rifa|campanha solidaria|sorteio de influenciador)\b"),
             "Vaquinhas, rifas e campanhas falsas usam perfis de influenciadores e empresas para pedir Pix. Confira se a chave Pix está no nome do responsável e se o perfil é antigo e verificado."),

            (R(@"\b(oi|ola|bom dia|boa tarde|boa noite|e ai|opa|ajuda)\b"),
             "Olá! Eu sou o assistente do ContraGolpe. Posso explicar como funcionam golpes de Pix, WhatsApp, boleto, links falsos e falsos prêmios, ensinar a se proteger e dizer o que fazer se você caiu em um golpe. Sobre o que você quer conversar?"),

            (R(@"\b(obrigad\w*|valeu|agradec\w*)\b"),
             "De nada! Se surgir outra dúvida ou mensagem suspeita, é só me chamar. Fique atento e nunca compartilhe códigos ou senhas."),

            (R(@"\b(pix|chave pix|comprovante)\b"),
             "Golpes com Pix: o golpista pede uma transferência com pressa, manda comprovante falso ou diz que fez o Pix errado e pede devolução.\n" +
             "Dicas: confira o nome do destinatário no app antes de confirmar, nunca devolva Pix sem verificar no seu extrato e desconfie de quem cria urgência."),

            (R(@"\b(whatsapp|zap|numero novo|mudei de numero|perdi meu celular|codigo de verificacao|clonar)\b"),
             "No golpe do WhatsApp, alguém se passa por parente com número novo e pede dinheiro, ou tenta fazer você passar o código de 6 dígitos para clonar sua conta.\n" +
             "Proteção: ligue para o número antigo da pessoa, ative a verificação em duas etapas do WhatsApp e nunca repasse o código recebido por SMS."),

            (R(@"\b(boleto|codigo de barras|segunda via|fatura)\b"),
             "No golpe do boleto, o código de barras é trocado e o dinheiro vai para a conta do golpista.\n" +
             "Dicas: confira o nome do beneficiário antes de pagar, use o app oficial da empresa e desconfie de segunda via enviada por mensagem."),

            (R(@"\b(link|sms|e-?mail|phishing|site falso|clique|anexo)\b"),
             "Links e e-mails falsos (phishing) imitam bancos e lojas para roubar seus dados.\n" +
             "Dicas: não clique em links recebidos por mensagem, digite o endereço do site você mesmo, desconfie de urgência e de endereços estranhos ou encurtados. Cole o texto na página Analisar Mensagem para uma checagem rápida."),

            (R(@"\b(premio|sorteio|ganhei|brinde|heranca|restituicao)\b"),
             "Prêmio ou sorteio em que você nunca se inscreveu quase sempre é golpe. Se pedem taxa, dados ou Pix para liberar o prêmio, é fraude. Não clique e não envie nada."),

            (R(@"\b(investimento|renda extra|lucro|cripto|bitcoin|trabalho em casa|vaga|emprego|curtir|tarefa)\b"),
             "Promessas de lucro garantido, renda extra fácil ou vagas que pedem depósito antecipado são sinais clássicos de golpe. Nenhum investimento sério garante ganho. Pesquise a empresa e desconfie de quem pede pagamento antes de começar."),

            (R(@"\b(banco|central|gerente|cartao|ligacao|telefone|motoboy|fraude na conta)\b"),
             "Golpe da falsa central: ligam dizendo ser do banco, falam de compra suspeita e pedem senha, código ou até buscam seu cartão.\n" +
             "O banco nunca pede senha ou código por telefone e não envia motoboy. Desligue e ligue para o número do verso do cartão."),

            (R(@"\b(senha|seguranca|proteger|protecao|dica|autenticacao|duas etapas|2fa)\b"),
             "Boas práticas: use senhas diferentes e longas, ative a verificação em duas etapas, nunca compartilhe códigos recebidos, atualize o celular e os apps e desconfie de qualquer pressa ou promessa fácil."),

            (R(@"\b(como funciona|como uso|como denunci|como registr|denunciar|denuncia|cadastr|conta|site|plataforma)\b"),
             "No ContraGolpe você pode: criar uma conta e entrar com verificação por e-mail, registrar uma denúncia (pode ser anônima), pesquisar golpes já relatados, ver os tipos de golpes comuns e analisar uma mensagem suspeita na página Analisar Mensagem."),
        };

        private string RespostaPronta(string texto)
        {
            var normal = Normalizar(texto);

            if (string.IsNullOrWhiteSpace(normal))
                return "Escreva sua dúvida sobre golpes ou cole uma mensagem suspeita que eu ajudo.";

            // 1) Situação de vítima tem prioridade
            var vitima = Intencoes[0];
            if (vitima.Padrao.IsMatch(normal))
                return vitima.Resposta;

            // 2) Texto longo ou com link: usa o analisador de mensagens
            if (normal.Length >= 40 || normal.Contains("http") || normal.Contains("www."))
            {
                var analise = _analisador.Analisar(texto);
                if (analise.Nivel != NivelRisco.Baixo)
                {
                    var nivel = analise.Nivel == NivelRisco.Alto ? "ALTO" : "MÉDIO";
                    var sb = new StringBuilder();
                    sb.Append($"Analisei esse texto e o risco é {nivel} ({analise.Pontuacao}/100). Sinais encontrados:\n");
                    foreach (var s in analise.Sinais.OrderByDescending(x => x.Pontos).Take(3))
                        sb.Append("- ").Append(s.Descricao).Append('\n');
                    sb.Append("\nO que fazer: ").Append(analise.Recomendacoes.FirstOrDefault() ?? "desconfie e confirme por outro canal.");
                    return sb.ToString();
                }
            }

            // 3) Demais assuntos por palavra-chave
            foreach (var (padrao, resposta) in Intencoes.Skip(1))
            {
                if (padrao.IsMatch(normal))
                    return resposta;
            }

            return "Ainda não entendi bem. Posso falar sobre golpes de Pix, WhatsApp, boleto, links falsos, falso prêmio, falsa central e o que fazer se você caiu em um golpe. Você também pode colar aqui uma mensagem suspeita para eu analisar.";
        }

        private static string Normalizar(string texto)
        {
            var d = (texto ?? "").ToLowerInvariant().Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder(d.Length);
            foreach (var c in d)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            return Regex.Replace(sb.ToString(), @"\s+", " ").Trim();
        }
    }
}
