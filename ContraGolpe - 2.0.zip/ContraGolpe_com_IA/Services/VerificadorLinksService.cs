using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace WebApplication1.Services
{
    public enum StatusLink { Perigoso, SemAlerta, NaoVerificado }

    public class ResultadoLink
    {
        public string Url { get; set; } = string.Empty;
        public StatusLink Status { get; set; }
        public string Detalhe { get; set; } = string.Empty;
    }

    public interface IVerificadorLinksService
    {
        bool Configurado { get; }
        IReadOnlyList<string> ExtrairLinks(string texto);
        Task<List<ResultadoLink>> VerificarAsync(IEnumerable<string> urls, CancellationToken ct = default);
    }

    /// <summary>
    /// Consulta o Google Safe Browsing (v4 threatMatches:find). O servidor NUNCA abre o link:
    /// só envia o endereço ao Google, o que evita SSRF e execução de conteúdo malicioso.
    /// Chave gratuita: SafeBrowsing:ApiKey (user-secrets).
    /// </summary>
    public class VerificadorLinksService : IVerificadorLinksService
    {
        private const int MaxLinks = 5;

        private static readonly Regex RegexUrl =
            new(@"(https?://[^\s<>""']+|www\.[^\s<>""']+|\b[a-z0-9-]+(\.[a-z0-9-]+)+/[^\s<>""']*)",
                RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private readonly HttpClient _http;
        private readonly IConfiguration _config;
        private readonly ILogger<VerificadorLinksService> _logger;

        public VerificadorLinksService(HttpClient http, IConfiguration config, ILogger<VerificadorLinksService> logger)
        {
            _http = http;
            _config = config;
            _logger = logger;
        }

        private string Chave => _config["SafeBrowsing:ApiKey"] ?? "";
        private string UrlBase => (_config["SafeBrowsing:BaseUrl"] is { Length: > 0 } u ? u : "https://safebrowsing.googleapis.com").TrimEnd('/');

        public bool Configurado =>
            !string.IsNullOrWhiteSpace(Chave) && !Chave.StartsWith("COLOQUE_", StringComparison.OrdinalIgnoreCase);

        public IReadOnlyList<string> ExtrairLinks(string texto)
        {
            var lista = new List<string>();
            if (string.IsNullOrWhiteSpace(texto)) return lista;

            foreach (Match m in RegexUrl.Matches(texto))
            {
                var url = m.Value.TrimEnd('.', ',', ')', '!', '?', ';');
                if (!url.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                    url = "http://" + url;

                if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) ||
                    (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
                    continue;

                if (!lista.Contains(url, StringComparer.OrdinalIgnoreCase))
                    lista.Add(url);

                if (lista.Count >= MaxLinks) break;
            }

            return lista;
        }

        public async Task<List<ResultadoLink>> VerificarAsync(IEnumerable<string> urls, CancellationToken ct = default)
        {
            var lista = urls.Take(MaxLinks).ToList();
            var resultados = lista
                .Select(u => new ResultadoLink { Url = u, Status = StatusLink.NaoVerificado })
                .ToList();

            if (resultados.Count == 0) return resultados;

            if (!Configurado)
            {
                foreach (var r in resultados)
                    r.Detalhe = "Verificação externa não configurada neste servidor.";
                return resultados;
            }

            var corpo = new
            {
                client = new { clientId = "contragolpe", clientVersion = "1.0" },
                threatInfo = new
                {
                    threatTypes = new[] { "MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION" },
                    platformTypes = new[] { "ANY_PLATFORM" },
                    threatEntryTypes = new[] { "URL" },
                    threatEntries = lista.Select(u => new { url = u }).ToArray()
                }
            };

            try
            {
                var endereco = $"{UrlBase}/v4/threatMatches:find?key={Uri.EscapeDataString(Chave)}";
                using var req = new HttpRequestMessage(HttpMethod.Post, endereco)
                {
                    Content = new StringContent(JsonSerializer.Serialize(corpo), Encoding.UTF8, "application/json")
                };

                using var resp = await _http.SendAsync(req, ct);
                var json = await resp.Content.ReadAsStringAsync(ct);

                if (!resp.IsSuccessStatusCode)
                {
                    _logger.LogWarning("Safe Browsing respondeu {Status}.", (int)resp.StatusCode);
                    foreach (var r in resultados)
                        r.Detalhe = "Serviço de verificação indisponível no momento.";
                    return resultados;
                }

                var perigosos = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("matches", out var matches) && matches.ValueKind == JsonValueKind.Array)
                {
                    foreach (var m in matches.EnumerateArray())
                    {
                        if (!m.TryGetProperty("threat", out var threat) ||
                            !threat.TryGetProperty("url", out var u)) continue;

                        var tipo = m.TryGetProperty("threatType", out var t) ? t.GetString() ?? "" : "";
                        perigosos[u.GetString() ?? ""] = TraduzirAmeaca(tipo);
                    }
                }

                foreach (var r in resultados)
                {
                    if (perigosos.TryGetValue(r.Url, out var descricao))
                    {
                        r.Status = StatusLink.Perigoso;
                        r.Detalhe = descricao;
                    }
                    else
                    {
                        r.Status = StatusLink.SemAlerta;
                        r.Detalhe = "Não consta nas listas de ameaças do Google. Isso não garante que seja seguro.";
                    }
                }
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Falha ao consultar o Safe Browsing.");
                foreach (var r in resultados)
                    r.Detalhe = "Não foi possível verificar agora.";
            }

            return resultados;
        }

        private static string TraduzirAmeaca(string tipo) => tipo switch
        {
            "SOCIAL_ENGINEERING" => "Phishing / engenharia social (site que imita outro para roubar dados)",
            "MALWARE" => "Distribui malware (programa malicioso)",
            "UNWANTED_SOFTWARE" => "Distribui software indesejado",
            "POTENTIALLY_HARMFUL_APPLICATION" => "Aplicativo potencialmente nocivo",
            _ => "Ameaça conhecida"
        };
    }
}
