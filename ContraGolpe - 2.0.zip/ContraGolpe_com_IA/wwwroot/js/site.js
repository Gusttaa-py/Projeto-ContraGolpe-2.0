document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".senha-wrapper").forEach(function (wrapper) {
        const input = wrapper.querySelector("input");
        const btn = wrapper.querySelector("button");
        if (!input || !btn) return;

        btn.addEventListener("click", function () {
            const mostrando = input.type === "text";
            input.type = mostrando ? "password" : "text";
            btn.textContent = mostrando ? "👁 Mostrar" : "🙈 Ocultar";
            btn.setAttribute("aria-label", mostrando ? "Mostrar senha" : "Ocultar senha");
            input.focus();
        });
    });
});
