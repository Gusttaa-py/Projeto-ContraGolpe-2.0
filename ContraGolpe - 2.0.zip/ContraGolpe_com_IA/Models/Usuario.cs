using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Usuario
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome é obrigatório.")]
        [StringLength(100)]
        public string Nome { get; set; } = "";

        [Required(ErrorMessage = "O e-mail é obrigatório.")]
        [EmailAddress(ErrorMessage = "E-mail inválido.")]
        [StringLength(200)]
        public string Email { get; set; } = "";

        [Required]
        public string SenhaHash { get; set; } = "";

        public string? Avatar { get; set; }  // ← linha nova (nome do arquivo)


        public DateTime CriadoEm { get; set; } = DateTime.Now;
    }
}