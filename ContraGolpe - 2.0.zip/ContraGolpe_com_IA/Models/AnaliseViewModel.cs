using System.ComponentModel.DataAnnotations;
using WebApplication1.Services;

namespace WebApplication1.Models
{
    public class AnaliseViewModel
    {
        [Required(ErrorMessage = "Cole a mensagem que deseja analisar.")]
        [StringLength(2000, ErrorMessage = "A mensagem pode ter no máximo 2000 caracteres.")]
        [Display(Name = "Mensagem suspeita")]
        public string Mensagem { get; set; } = string.Empty;

        // Pedido de orientação personalizada com IA generativa (opcional)
        public bool UsarIA { get; set; }

        [StringLength(500, ErrorMessage = "A descrição da situação pode ter no máximo 500 caracteres.")]
        public string? Situacao { get; set; }

        // ── Saídas (preenchidas pelo servidor) ──
        public ResultadoAnalise? Resultado { get; set; }
        public List<ResultadoLink> Links { get; set; } = new();
        public string? Orientacao { get; set; }
        public string? ErroIA { get; set; }

        // Denúncias já registradas no sistema parecidas com o tipo detectado.
        public List<Denuncia> DenunciasSemelhantes { get; set; } = new();

        // Análise de imagem / captura de tela
        public ResultadoImagem? ImagemResultado { get; set; }
        public string? ErroImagem { get; set; }

        // Quais recursos externos estão configurados (para a tela avisar o usuário)
        public bool IaDisponivel { get; set; }
        public bool LinksDisponivel { get; set; }
        public bool UsuarioLogado { get; set; }
    }
}
