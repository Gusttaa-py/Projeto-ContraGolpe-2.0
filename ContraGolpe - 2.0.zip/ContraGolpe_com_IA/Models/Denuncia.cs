﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Denuncia
    {
        public int Id { get; set; }

        [Display(Name = "Nome")]
        public string? Nome { get; set; }

        [Required(ErrorMessage = "A categoria é obrigatória.")]
        [Display(Name = "Categoria")]
        public string Categoria { get; set; } = string.Empty;

        [Required(ErrorMessage = "O tipo de golpe é obrigatório.")]
        [Display(Name = "Tipo de Golpe")]
        public string TipoGolpe { get; set; } = string.Empty;

        [Required(ErrorMessage = "A descrição é obrigatória.")]
        [StringLength(500, ErrorMessage = "A descrição pode ter no máximo 500 caracteres.")]
        [Display(Name = "Descrição")]
        public string Descricao { get; set; } = string.Empty;

        [Required(ErrorMessage = "O local da ocorrência é obrigatório.")]
        [Display(Name = "Local da Ocorrência")]
        public string LocalOcorrencia { get; set; } = string.Empty;

        // Quem registrou (null = anônima ou registrada antes deste campo existir).
        // Não aparece no formulário: é preenchido pelo servidor.
        public int? UsuarioId { get; set; }

        [Display(Name = "Data da Denúncia")]
        public DateTime DataDenuncia { get; set; } = DateTime.Now;
    }
}