namespace WebApplication1.Models
{
    public class ChatRequest
    {
        public string Mensagem { get; set; } = string.Empty;
    }

    public class ClassificarRequest
    {
        public string Descricao { get; set; } = string.Empty;
    }
}
