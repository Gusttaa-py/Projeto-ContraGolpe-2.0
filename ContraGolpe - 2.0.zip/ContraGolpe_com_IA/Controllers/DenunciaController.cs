using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    public class DenunciaController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IClaudeService _claude;
        private readonly IConfiguration _configuration;

        public DenunciaController(AppDbContext context, IClaudeService claude, IConfiguration configuration)
        {
            _context = context;
            _claude = claude;
            _configuration = configuration;
        }

        public IActionResult GolpesComuns()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        // Bind: só aceita os campos do formulário (impede enviar Id ou DataDenuncia manualmente).
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(
            [Bind("Nome,Categoria,TipoGolpe,Descricao,LocalOcorrencia")] Denuncia denuncia)
        {
            denuncia.Nome = string.IsNullOrWhiteSpace(denuncia.Nome) ? null : denuncia.Nome.Trim();
            denuncia.Categoria = (denuncia.Categoria ?? "").Trim();
            denuncia.TipoGolpe = (denuncia.TipoGolpe ?? "").Trim();
            denuncia.Descricao = (denuncia.Descricao ?? "").Trim();
            denuncia.LocalOcorrencia = (denuncia.LocalOcorrencia ?? "").Trim();

            // Limites para evitar textos gigantes (as colunas do banco não têm tamanho máximo)
            if ((denuncia.Nome?.Length ?? 0) > 100)
                ModelState.AddModelError(nameof(Denuncia.Nome), "O nome pode ter no máximo 100 caracteres.");
            if (denuncia.Categoria.Length > 60)
                ModelState.AddModelError(nameof(Denuncia.Categoria), "A categoria pode ter no máximo 60 caracteres.");
            if (denuncia.TipoGolpe.Length > 120)
                ModelState.AddModelError(nameof(Denuncia.TipoGolpe), "O tipo de golpe pode ter no máximo 120 caracteres.");
            if (denuncia.LocalOcorrencia.Length > 200)
                ModelState.AddModelError(nameof(Denuncia.LocalOcorrencia), "O local pode ter no máximo 200 caracteres.");

            if (!ModelState.IsValid)
            {
                return View(denuncia);
            }

            denuncia.DataDenuncia = DateTime.Now;

            // Vincula ao autor só quando está logado e não escolheu enviar como anônimo.
            var usuarioId = HttpContext.Session.GetInt32("UsuarioId");
            if (usuarioId != null && denuncia.Nome != null)
                denuncia.UsuarioId = usuarioId;

            _context.Denuncias.Add(denuncia);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Registrada));
        }

        // Tela exibida logo após registrar a denúncia: confirma e encaminha para o B.O. online.
        // O B.O. online é feito pela Polícia Civil de cada estado. O endereço pode ser trocado
        // em appsettings.json > BoletimOcorrencia:Url (o padrão é a Delegacia Eletrônica de São Paulo).
        [HttpGet]
        public IActionResult Registrada()
        {
            ViewBag.UrlBoletim = _configuration["BoletimOcorrencia:Url"] is { Length: > 0 } u
                ? u
                : "https://www.delegaciaeletronica.policiacivil.sp.gov.br/";
            return View();
        }

        public async Task<IActionResult> Listar()
        {
            var denuncias = await _context.Denuncias
                .OrderByDescending(d => d.DataDenuncia)
                .ToListAsync();

            return View(denuncias);
        }

        public async Task<IActionResult> Buscar(string termo, bool inteligente, CancellationToken ct)
        {
            termo = termo?.Trim();
            ViewBag.Termo = termo;
            ViewBag.BuscaRealizada = !string.IsNullOrWhiteSpace(termo);
            ViewBag.Inteligente = inteligente;
            ViewBag.IaDisponivel = _claude.Configurado;
            ViewBag.PalavrasIA = null;
            ViewBag.AvisoIA = null;

            if (string.IsNullOrWhiteSpace(termo))
            {
                return View(new List<Denuncia>());
            }

            if (termo.Length > 200)
                termo = termo[..200];

            // Pesquisa inteligente: a IA converte a pergunta em palavras-chave.
            // Se não estiver disponível ou falhar, cai na busca comum (nunca deixa o usuário sem resultado).
            var palavras = new List<string> { termo };

            if (inteligente)
            {
                if (!_claude.Configurado)
                {
                    ViewBag.AvisoIA = "A pesquisa inteligente não está configurada neste servidor. Mostrando a busca comum.";
                }
                else
                {
                    try
                    {
                        var interpretadas = await _claude.InterpretarBuscaAsync(termo, ct);
                        if (interpretadas.Count > 0)
                        {
                            palavras = interpretadas.ToList();
                            ViewBag.PalavrasIA = palavras;
                        }
                    }
                    catch (ServicoIAException ex)
                    {
                        ViewBag.AvisoIA = ex.Message + " Mostrando a busca comum.";
                    }
                }
            }

            var resultado = new List<Denuncia>();
            var idsVistos = new HashSet<int>();

            foreach (var palavra in palavras.Take(5))
            {
                var padrao = "%" + EscaparLike(palavra) + "%";

                var achados = await _context.Denuncias
                    .Where(d =>
                        EF.Functions.Like(d.TipoGolpe, padrao, "\\") ||
                        EF.Functions.Like(d.Categoria, padrao, "\\") ||
                        EF.Functions.Like(d.Descricao, padrao, "\\"))
                    .OrderByDescending(d => d.DataDenuncia)
                    .Take(50)
                    .ToListAsync(ct);

                foreach (var d in achados)
                {
                    if (idsVistos.Add(d.Id))
                        resultado.Add(d);
                }
            }

            resultado = resultado.OrderByDescending(d => d.DataDenuncia).ToList();
            return View(resultado);
        }

        // Classificação automática de uma nova denúncia (chamada pelo formulário via JavaScript)
        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("ia")]
        public async Task<IActionResult> Classificar([FromBody] ClassificarRequest pedido, CancellationToken ct)
        {
            var descricao = (pedido?.Descricao ?? "").Trim();

            if (descricao.Length < 20)
                return BadRequest(new { erro = "Descreva o ocorrido com um pouco mais de detalhes (mínimo de 20 caracteres)." });
            if (descricao.Length > 500)
                descricao = descricao[..500];

            if (!_claude.Configurado)
                return StatusCode(503, new { erro = "A classificação por IA ainda não foi configurada neste servidor." });

            try
            {
                var c = await _claude.ClassificarDenunciaAsync(descricao, ct);
                return Json(new { categoria = c.Categoria, tipoGolpe = c.TipoGolpe, risco = c.Risco, resumo = c.Resumo });
            }
            catch (ServicoIAException ex)
            {
                return StatusCode(502, new { erro = ex.Message });
            }
        }

        private static string EscaparLike(string texto)
        {
            // Escapa %, _ e [ digitados pelo usuário, para valerem como texto comum no LIKE
            return (texto ?? "")
                .Replace("\\", "\\\\")
                .Replace("%", "\\%")
                .Replace("_", "\\_")
                .Replace("[", "\\[");
        }

        // ── EXCLUIR (só o autor ou um administrador) ──────

        public async Task<IActionResult> Excluir(int id)
        {
            if (!UsuarioLogado())
                return PedirLogin();

            var denuncia = await _context.Denuncias.FindAsync(id);

            if (denuncia == null)
            {
                return NotFound();
            }

            if (!PodeExcluir(denuncia))
                return SemPermissao();

            return View(denuncia);
        }

        [HttpPost, ActionName("Excluir")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ExcluirConfirmado(int id)
        {
            if (!UsuarioLogado())
                return PedirLogin();

            var denuncia = await _context.Denuncias.FindAsync(id);

            if (denuncia != null)
            {
                if (!PodeExcluir(denuncia))
                    return SemPermissao();

                _context.Denuncias.Remove(denuncia);
                await _context.SaveChangesAsync();
            }

            TempData["MensagemSucesso"] = "Denúncia excluída com sucesso!";

            return RedirectToAction(nameof(Listar));
        }

        private bool UsuarioLogado()
        {
            return HttpContext.Session.GetInt32("UsuarioId") != null;
        }

        // Autor da denúncia ou administrador (lista Admin:Emails no appsettings.json).
        private bool PodeExcluir(Denuncia denuncia)
        {
            var usuarioId = HttpContext.Session.GetInt32("UsuarioId");
            if (usuarioId == null)
                return false;

            if (HttpContext.Session.GetString("UsuarioAdmin") == "1")
                return true;

            return denuncia.UsuarioId != null && denuncia.UsuarioId == usuarioId;
        }

        private IActionResult SemPermissao()
        {
            TempData["MensagemErro"] = "Você só pode excluir denúncias registradas por você.";
            return RedirectToAction(nameof(Listar));
        }

        private IActionResult PedirLogin()
        {
            TempData["MensagemErro"] = "Faça login para excluir denúncias.";
            return RedirectToAction("Login", "Usuario");
        }
    }
}
