using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    public class ChatItem
    {
        public string Papel { get; set; } = "";
        public string Texto { get; set; } = "";
    }

    public class ChatRequisicao
    {
        public List<ChatItem> Mensagens { get; set; } = new();
    }

    public class ChatbotController : Controller
    {
        private const int MaxMensagens = 10;
        private const int MaxCaracteres = 800;

        private readonly IChatbotService _chatbot;

        public ChatbotController(IChatbotService chatbot)
        {
            _chatbot = chatbot;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        // Recebe o histórico da conversa (mantido no navegador) e devolve a próxima resposta.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("chat")]
        public async Task<IActionResult> Enviar([FromBody] ChatRequisicao requisicao)
        {
            if (requisicao?.Mensagens == null || requisicao.Mensagens.Count == 0)
                return BadRequest(new { erro = "Envie uma mensagem." });

            // Não confia no que veio do navegador: só aceita papéis válidos, limita tamanho e quantidade.
            var conversa = requisicao.Mensagens
                .Where(m => (m.Papel == "user" || m.Papel == "assistant") && !string.IsNullOrWhiteSpace(m.Texto))
                .TakeLast(MaxMensagens)
                .Select(m => new ChatMensagem
                {
                    Papel = m.Papel,
                    Texto = m.Texto.Length > MaxCaracteres ? m.Texto.Substring(0, MaxCaracteres) : m.Texto
                })
                .ToList();

            // A API exige que a conversa comece e termine com "user".
            while (conversa.Count > 0 && conversa[0].Papel != "user")
                conversa.RemoveAt(0);

            if (conversa.Count == 0 || conversa[^1].Papel != "user")
                return BadRequest(new { erro = "A última mensagem deve ser sua." });

            var resposta = await _chatbot.ResponderAsync(conversa);

            return Json(new { resposta = resposta.Texto, ia = resposta.UsouIA });
        }
    }
}
