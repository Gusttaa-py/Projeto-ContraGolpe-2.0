using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    public class UsuarioController : Controller
    {
        // Parâmetros de segurança
        private const int IteracoesPbkdf2 = 600_000;
        private const int MaxTentativas2FA = 5;
        private const int ValidadeCodigoMinutos = 10;
        private const int IntervaloReenvioSegundos = 30;

        // O código por e-mail só é pedido de novo depois de 30 dias neste navegador.
        private const int DiasVerificacaoEmail = 30;
        private const string FinalidadeEmailVerificado = "ContraGolpe.EmailVerificado.v1";

        private readonly AppDbContext _db;
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<UsuarioController> _logger;
        private readonly IDataProtector _protetorEmailVerificado;
        private readonly ArmazenamentoAvatares _avatares;

        public UsuarioController(
            AppDbContext db,
            IConfiguration configuration,
            IWebHostEnvironment env,
            ILogger<UsuarioController> logger,
            IDataProtectionProvider protecao,
            ArmazenamentoAvatares avatares)
        {
            _avatares = avatares;
            _db = db;
            _configuration = configuration;
            _env = env;
            _logger = logger;
            _protetorEmailVerificado = protecao.CreateProtector(FinalidadeEmailVerificado);
        }

        // ── REGISTRAR ──────────────────────────────────────

        [HttpGet]
        public IActionResult Registrar()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("autenticacao")]
        public async Task<IActionResult> Registrar(string nome, string email, string senha, string confirmar)
        {
            nome = (nome ?? "").Trim();
            email = (email ?? "").Trim().ToLowerInvariant();
            senha ??= "";

            ViewBag.Nome = nome;
            ViewBag.Email = email;

            // 1. Campos em branco
            if (nome.Length == 0 || email.Length == 0 || senha.Length == 0)
            {
                ModelState.AddModelError("", "Preencha todos os campos.");
                return View();
            }

            // 2. Tamanhos máximos (iguais aos do banco)
            if (nome.Length > 100)
            {
                ModelState.AddModelError("", "O nome pode ter no máximo 100 caracteres.");
                return View();
            }

            if (email.Length > 200 || !new EmailAddressAttribute().IsValid(email))
            {
                ModelState.AddModelError("", "Informe um e-mail válido.");
                return View();
            }

            // 3. Senhas diferentes
            if (senha != confirmar)
            {
                ModelState.AddModelError("", "As senhas não coincidem.");
                return View();
            }

            // 4. Senha fraca / grande demais
            if (senha.Length < 6)
            {
                ModelState.AddModelError("", "A senha deve ter pelo menos 6 caracteres.");
                return View();
            }

            if (senha.Length > 128)
            {
                ModelState.AddModelError("", "A senha pode ter no máximo 128 caracteres.");
                return View();
            }

            // 5. E-mail já cadastrado
            if (await _db.Usuarios.AnyAsync(u => u.Email == email))
            {
                ModelState.AddModelError("", "Este e-mail já está cadastrado.");
                return View();
            }

            // 6. Salvar usuário com senha em hash (PBKDF2 + salt)
            var usuario = new Usuario
            {
                Nome = nome,
                Email = email,
                SenhaHash = GerarHash(senha)
            };

            _db.Usuarios.Add(usuario);

            try
            {
                await _db.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                // Duas requisições simultâneas com o mesmo e-mail: o índice UNIQUE barra a segunda.
                _logger.LogWarning(ex, "Falha ao salvar novo usuário.");
                ModelState.AddModelError("", "Este e-mail já está cadastrado.");
                return View();
            }

            TempData["MensagemSucesso"] = "Conta criada com sucesso! Faça login.";
            return RedirectToAction("Login");
        }

        // ── LOGIN ──────────────────────────────────────────

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("autenticacao")]
        public async Task<IActionResult> Login(string email, string senha)
        {
            email = (email ?? "").Trim().ToLowerInvariant();
            ViewBag.Email = email;

            if (email.Length == 0 || string.IsNullOrWhiteSpace(senha))
            {
                ModelState.AddModelError("", "Preencha e-mail e senha.");
                return View();
            }

            var usuario = await _db.Usuarios.FirstOrDefaultAsync(u => u.Email == email);

            if (usuario == null)
            {
                _ = GerarHash(senha); // gasta o mesmo tempo, para não revelar se o e-mail existe
                ModelState.AddModelError("", "E-mail ou senha incorretos.");
                return View();
            }

            if (!VerificarSenha(senha, usuario.SenhaHash, out var precisaAtualizar))
            {
                ModelState.AddModelError("", "E-mail ou senha incorretos.");
                return View();
            }

            // Contas antigas (SHA-256 sem salt) são migradas para PBKDF2 no primeiro login.
            if (precisaAtualizar)
            {
                usuario.SenhaHash = GerarHash(senha);
                await _db.SaveChangesAsync();
            }

            // E-mail já verificado nos últimos 30 dias neste navegador: entra direto.
            if (EmailVerificadoRecentemente(usuario))
            {
                LimparSessao2FA();
                IniciarSessao(usuario);
                return RedirectToAction("Index", "Home");
            }

            var codigo = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();

            HttpContext.Session.SetInt32("Usuario2FAId", usuario.Id);
            HttpContext.Session.SetString("Usuario2FANome", usuario.Nome);
            DefinirCodigo2FA(codigo);

            // Só em desenvolvimento: sem SMTP configurado, mostra o código na tela para dar para entrar.
            if (_env.IsDevelopment() && !SmtpConfigurado())
            {
                _logger.LogWarning("SMTP não configurado (modo desenvolvimento). Código 2FA de {Email}: {Codigo}", usuario.Email, codigo);
                TempData["MensagemSucesso"] = $"Modo desenvolvimento: o envio de e-mail (SMTP) não está configurado, então seu código é {codigo}.";
                return RedirectToAction("VerificarCodigo");
            }

            try
            {
                await EnviarCodigoPorEmail(usuario.Email, usuario.Nome, codigo);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Falha ao enviar o código 2FA por e-mail.");
                LimparSessao2FA();
                ModelState.AddModelError("", "Não foi possível enviar o código por e-mail. Confira as configurações SMTP no appsettings.json.");
                return View();
            }

            TempData["MensagemSucesso"] = "Enviamos um código de verificação para o seu e-mail.";
            return RedirectToAction("VerificarCodigo");
        }

        // ── VERIFICAÇÃO EM DUAS ETAPAS ────────────────────

        [HttpGet]
        public IActionResult VerificarCodigo()
        {
            if (HttpContext.Session.GetInt32("Usuario2FAId") == null)
                return RedirectToAction("Login");

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("autenticacao")]
        public async Task<IActionResult> VerificarCodigo(string codigo, bool lembrar)
        {
            var usuarioId = HttpContext.Session.GetInt32("Usuario2FAId");
            var codigoSessao = HttpContext.Session.GetString("Codigo2FA");
            var expiracaoTexto = HttpContext.Session.GetString("Codigo2FAExpira");

            if (usuarioId == null || string.IsNullOrWhiteSpace(codigoSessao) || string.IsNullOrWhiteSpace(expiracaoTexto))
                return RedirectToAction("Login");

            if (!long.TryParse(expiracaoTexto, out var expiraTicks) || DateTime.UtcNow.Ticks > expiraTicks)
            {
                LimparSessao2FA();
                TempData["MensagemErro"] = "O código expirou. Faça login novamente para receber outro código.";
                return RedirectToAction("Login");
            }

            var tentativas = (HttpContext.Session.GetInt32("Tentativas2FA") ?? 0) + 1;
            HttpContext.Session.SetInt32("Tentativas2FA", tentativas);

            if (tentativas > MaxTentativas2FA)
            {
                LimparSessao2FA();
                TempData["MensagemErro"] = "Muitas tentativas incorretas. Faça login novamente.";
                return RedirectToAction("Login");
            }

            codigo = (codigo ?? "").Trim();

            var iguais = CryptographicOperations.FixedTimeEquals(
                Encoding.UTF8.GetBytes(codigo),
                Encoding.UTF8.GetBytes(codigoSessao));

            if (!iguais)
            {
                var restantes = MaxTentativas2FA - tentativas;
                ModelState.AddModelError("", restantes > 0
                    ? $"Código incorreto. Você ainda tem {restantes} tentativa(s)."
                    : "Código incorreto. Esta foi a última tentativa.");
                return View();
            }

            var usuario = await _db.Usuarios.FindAsync(usuarioId.Value);
            if (usuario == null)
            {
                LimparSessao2FA();
                return RedirectToAction("Login");
            }

            IniciarSessao(usuario);

            // Marca o e-mail como verificado neste navegador pelos próximos 30 dias.
            if (lembrar)
                MarcarEmailVerificado(usuario);
            else
                Response.Cookies.Delete(NomeCookieEmailVerificado(usuario.Id));

            LimparSessao2FA();

            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("autenticacao")]
        public async Task<IActionResult> ReenviarCodigo()
        {
            var usuarioId = HttpContext.Session.GetInt32("Usuario2FAId");
            if (usuarioId == null)
                return RedirectToAction("Login");

            // Evita disparar e-mails em sequência
            var enviadoTexto = HttpContext.Session.GetString("Codigo2FAEnviadoEm");
            if (long.TryParse(enviadoTexto, out var enviadoTicks))
            {
                var decorrido = TimeSpan.FromTicks(DateTime.UtcNow.Ticks - enviadoTicks);
                if (decorrido.TotalSeconds < IntervaloReenvioSegundos)
                {
                    var faltam = (int)Math.Ceiling(IntervaloReenvioSegundos - decorrido.TotalSeconds);
                    TempData["MensagemErro"] = $"Aguarde {faltam} segundo(s) para pedir um novo código.";
                    return RedirectToAction("VerificarCodigo");
                }
            }

            var usuario = await _db.Usuarios.FindAsync(usuarioId.Value);
            if (usuario == null)
            {
                LimparSessao2FA();
                return RedirectToAction("Login");
            }

            var codigo = RandomNumberGenerator.GetInt32(100000, 1000000).ToString();
            DefinirCodigo2FA(codigo);

            if (_env.IsDevelopment() && !SmtpConfigurado())
            {
                _logger.LogWarning("SMTP não configurado (modo desenvolvimento). Novo código 2FA de {Email}: {Codigo}", usuario.Email, codigo);
                TempData["MensagemSucesso"] = $"Modo desenvolvimento: o envio de e-mail (SMTP) não está configurado, então seu novo código é {codigo}.";
                return RedirectToAction("VerificarCodigo");
            }

            try
            {
                await EnviarCodigoPorEmail(usuario.Email, usuario.Nome, codigo);
                TempData["MensagemSucesso"] = "Novo código enviado para o seu e-mail.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Falha ao reenviar o código 2FA.");
                TempData["MensagemErro"] = "Não foi possível reenviar o código. Confira as configurações SMTP.";
            }

            return RedirectToAction("VerificarCodigo");
        }

        // ── PERFIL ────────────────────────────────────────

        [HttpGet]
        public async Task<IActionResult> Perfil()
        {
            // Se não estiver logado, manda para o login
            var id = HttpContext.Session.GetInt32("UsuarioId");
            if (id == null)
                return RedirectToAction("Login");

            var usuario = await _db.Usuarios.FindAsync(id.Value);
            if (usuario == null)
                return RedirectToAction("Login");

            ViewBag.TotalDenuncias = 0;
            ViewBag.MembroDesde = usuario.CriadoEm.ToString("MMMM 'de' yyyy", new CultureInfo("pt-BR"));

            return View(usuario);
        }

        // ── EDITAR AVATAR ─────────────────────────────────

        [HttpGet]
        public async Task<IActionResult> EditarAvatar()
        {
            var id = HttpContext.Session.GetInt32("UsuarioId");
            if (id == null) return RedirectToAction("Login");

            var usuario = await _db.Usuarios.FindAsync(id.Value);
            if (usuario == null) return RedirectToAction("Login");

            return View(usuario);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarAvatar(IFormFile arquivo)
        {
            var id = HttpContext.Session.GetInt32("UsuarioId");
            if (id == null) return RedirectToAction("Login");

            var usuario = await _db.Usuarios.FindAsync(id.Value);
            if (usuario == null) return RedirectToAction("Login");

            if (arquivo == null || arquivo.Length == 0)
            {
                ModelState.AddModelError("", "Selecione uma imagem.");
                return View(usuario);
            }

            // Só aceita imagens
            var extensoesPermitidas = new[] { ".jpg", ".jpeg", ".png", ".webp" };
            var extensao = Path.GetExtension(arquivo.FileName).ToLowerInvariant();
            if (!extensoesPermitidas.Contains(extensao))
            {
                ModelState.AddModelError("", "Formato inválido. Use JPG, PNG ou WEBP.");
                return View(usuario);
            }

            // Limite de 2MB
            if (arquivo.Length > 2 * 1024 * 1024)
            {
                ModelState.AddModelError("", "A imagem deve ter no máximo 2MB.");
                return View(usuario);
            }

            // O conteúdo precisa ser mesmo uma imagem (não basta a extensão)
            if (!await ConteudoCorrespondeExtensao(arquivo, extensao))
            {
                ModelState.AddModelError("", "O arquivo enviado não é uma imagem válida.");
                return View(usuario);
            }

            // Pasta fora do projeto: a foto não se perde ao atualizar ou trocar a pasta do projeto
            Directory.CreateDirectory(_avatares.Pasta);

            var avatarAntigo = usuario.Avatar;

            // Salvar novo arquivo com nome único
            var nomeArquivo = $"avatar_{id}_{Guid.NewGuid()}{extensao}";
            var caminho = Path.Combine(_avatares.Pasta, nomeArquivo);

            using (var stream = new FileStream(caminho, FileMode.Create))
            {
                await arquivo.CopyToAsync(stream);
            }

            // Atualizar banco e manter o avatar disponível na navbar após salvar
            usuario.Avatar = nomeArquivo;
            await _db.SaveChangesAsync();
            HttpContext.Session.SetString("UsuarioAvatar", nomeArquivo);

            // Só depois de salvar a nova foto é que a antiga é apagada
            ApagarAvatar(avatarAntigo);

            TempData["MensagemSucesso"] = "Avatar atualizado com sucesso!";
            return RedirectToAction("Perfil");
        }

        private void ApagarAvatar(string? nome)
        {
            if (string.IsNullOrWhiteSpace(nome))
                return;

            nome = Path.GetFileName(nome);
            var locais = new[]
            {
                Path.Combine(_avatares.Pasta, nome),
                Path.Combine(_env.WebRootPath, "avatars", nome)   // fotos antigas, de antes da mudança de pasta
            };

            foreach (var caminho in locais)
            {
                try
                {
                    if (System.IO.File.Exists(caminho))
                        System.IO.File.Delete(caminho);
                }
                catch (IOException ex)
                {
                    _logger.LogWarning(ex, "Não foi possível apagar o avatar antigo {Arquivo}.", caminho);
                }
            }
        }

        // ── LOGOUT ────────────────────────────────────────

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        // ── HELPERS ───────────────────────────────────────

        // Gera "PBKDF2$iteracoes$salt$hash" com salt aleatório.
        private static string GerarHash(string senha)
        {
            var salt = RandomNumberGenerator.GetBytes(16);
            var hash = Rfc2898DeriveBytes.Pbkdf2(senha, salt, IteracoesPbkdf2, HashAlgorithmName.SHA256, 32);
            return $"PBKDF2${IteracoesPbkdf2}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
        }

        // Confere a senha. Aceita também o formato antigo (SHA-256 em hexadecimal, sem salt),
        // para que as contas já cadastradas continuem funcionando.
        private static bool VerificarSenha(string senha, string hashSalvo, out bool precisaAtualizar)
        {
            precisaAtualizar = false;

            if (string.IsNullOrEmpty(hashSalvo))
                return false;

            if (hashSalvo.StartsWith("PBKDF2$", StringComparison.Ordinal))
            {
                var partes = hashSalvo.Split('$');
                if (partes.Length != 4 || !int.TryParse(partes[1], out var iteracoes) || iteracoes <= 0)
                    return false;

                byte[] salt;
                byte[] esperado;
                try
                {
                    salt = Convert.FromBase64String(partes[2]);
                    esperado = Convert.FromBase64String(partes[3]);
                }
                catch (FormatException)
                {
                    return false;
                }

                var calculado = Rfc2898DeriveBytes.Pbkdf2(senha, salt, iteracoes, HashAlgorithmName.SHA256, esperado.Length);
                precisaAtualizar = iteracoes < IteracoesPbkdf2;
                return CryptographicOperations.FixedTimeEquals(calculado, esperado);
            }

            var legado = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(senha))).ToLowerInvariant();
            var confere = CryptographicOperations.FixedTimeEquals(
                Encoding.UTF8.GetBytes(legado),
                Encoding.UTF8.GetBytes(hashSalvo.Trim().ToLowerInvariant()));

            precisaAtualizar = confere;
            return confere;
        }

        // Cria a sessão de login (usada após a senha + e-mail verificado).
        private void IniciarSessao(Usuario usuario)
        {
            HttpContext.Session.SetInt32("UsuarioId", usuario.Id);
            HttpContext.Session.SetString("UsuarioNome", usuario.Nome);

            if (!string.IsNullOrWhiteSpace(usuario.Avatar))
                HttpContext.Session.SetString("UsuarioAvatar", usuario.Avatar);
            else
                HttpContext.Session.Remove("UsuarioAvatar");

            // Administradores (appsettings.json > Admin:Emails) podem excluir qualquer denúncia.
            var admins = _configuration.GetSection("Admin:Emails").Get<string[]>() ?? Array.Empty<string>();
            if (admins.Any(e => string.Equals(e?.Trim(), usuario.Email, StringComparison.OrdinalIgnoreCase)))
                HttpContext.Session.SetString("UsuarioAdmin", "1");
            else
                HttpContext.Session.Remove("UsuarioAdmin");
        }

        // ── E-mail verificado a cada 30 dias ──────────────
        // Guardamos no navegador um cookie protegido (criptografado e assinado) com o id do usuário,
        // a data da verificação e uma marca da senha atual. Ele vale por 30 dias e deixa de valer
        // se a senha mudar. Cada conta tem o seu cookie, e quem fizer logout continua verificado.

        private static string NomeCookieEmailVerificado(int usuarioId) => $"cg_email_ok_{usuarioId}";

        private static string MarcaDaSenha(Usuario usuario) =>
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(usuario.SenhaHash ?? ""))).Substring(0, 16);

        private void MarcarEmailVerificado(Usuario usuario)
        {
            var agora = DateTime.UtcNow;
            var token = _protetorEmailVerificado.Protect($"{usuario.Id}|{agora.Ticks}|{MarcaDaSenha(usuario)}");

            Response.Cookies.Append(NomeCookieEmailVerificado(usuario.Id), token, new CookieOptions
            {
                HttpOnly = true,
                IsEssential = true,
                SameSite = SameSiteMode.Lax,
                Secure = Request.IsHttps,
                Expires = new DateTimeOffset(agora).AddDays(DiasVerificacaoEmail)
            });
        }

        private bool EmailVerificadoRecentemente(Usuario usuario)
        {
            if (!Request.Cookies.TryGetValue(NomeCookieEmailVerificado(usuario.Id), out var token) ||
                string.IsNullOrWhiteSpace(token))
                return false;

            try
            {
                var partes = _protetorEmailVerificado.Unprotect(token).Split('|');
                if (partes.Length != 3 ||
                    !int.TryParse(partes[0], out var id) || id != usuario.Id ||
                    !long.TryParse(partes[1], out var ticks) ||
                    partes[2] != MarcaDaSenha(usuario))
                    return false;

                var verificadoEm = new DateTime(ticks, DateTimeKind.Utc);
                var idade = DateTime.UtcNow - verificadoEm;
                return idade >= TimeSpan.FromMinutes(-5) && idade < TimeSpan.FromDays(DiasVerificacaoEmail);
            }
            catch
            {
                // Cookie adulterado, de outra chave de criptografia ou ilegível: pede o código de novo.
                return false;
            }
        }

        private bool SmtpConfigurado()
        {
            var smtp = _configuration.GetSection("Smtp");
            var senha = smtp["Password"] ?? "";
            return !string.IsNullOrWhiteSpace(smtp["User"]) &&
                   !string.IsNullOrWhiteSpace(senha) &&
                   !senha.StartsWith("COLOQUE_", StringComparison.OrdinalIgnoreCase);
        }

        private void DefinirCodigo2FA(string codigo)
        {
            HttpContext.Session.SetString("Codigo2FA", codigo);
            HttpContext.Session.SetString("Codigo2FAExpira", DateTime.UtcNow.AddMinutes(ValidadeCodigoMinutos).Ticks.ToString());
            HttpContext.Session.SetString("Codigo2FAEnviadoEm", DateTime.UtcNow.Ticks.ToString());
            HttpContext.Session.SetInt32("Tentativas2FA", 0);
        }

        private void LimparSessao2FA()
        {
            HttpContext.Session.Remove("Usuario2FAId");
            HttpContext.Session.Remove("Usuario2FANome");
            HttpContext.Session.Remove("Codigo2FA");
            HttpContext.Session.Remove("Codigo2FAExpira");
            HttpContext.Session.Remove("Codigo2FAEnviadoEm");
            HttpContext.Session.Remove("Tentativas2FA");
        }

        // Confere os primeiros bytes (assinatura) do arquivo.
        private static async Task<bool> ConteudoCorrespondeExtensao(IFormFile arquivo, string extensao)
        {
            var c = new byte[12];
            int lidos;

            using (var stream = arquivo.OpenReadStream())
            {
                lidos = await stream.ReadAsync(c, 0, c.Length);
            }

            if (lidos < c.Length)
                return false;

            switch (extensao)
            {
                case ".jpg":
                case ".jpeg":
                    return c[0] == 0xFF && c[1] == 0xD8 && c[2] == 0xFF;

                case ".png":
                    return c[0] == 0x89 && c[1] == 0x50 && c[2] == 0x4E && c[3] == 0x47 &&
                           c[4] == 0x0D && c[5] == 0x0A && c[6] == 0x1A && c[7] == 0x0A;

                case ".webp":
                    return c[0] == 0x52 && c[1] == 0x49 && c[2] == 0x46 && c[3] == 0x46 &&   // "RIFF"
                           c[8] == 0x57 && c[9] == 0x45 && c[10] == 0x42 && c[11] == 0x50;  // "WEBP"

                default:
                    return false;
            }
        }

        private async Task EnviarCodigoPorEmail(string destino, string nome, string codigo)
        {
            var smtp = _configuration.GetSection("Smtp");
            var remetente = smtp["User"] ?? "";
            var senha = smtp["Password"] ?? "";
            var host = smtp["Host"] ?? "smtp.gmail.com";
            var porta = int.TryParse(smtp["Port"], out var p) ? p : 587;

            if (string.IsNullOrWhiteSpace(remetente) ||
                string.IsNullOrWhiteSpace(senha) ||
                senha.StartsWith("COLOQUE_", StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "SMTP não configurado: defina Smtp:Password (senha de app do Gmail) em user-secrets ou appsettings.json.");
            }

            using var mensagem = new MailMessage();
            mensagem.From = new MailAddress(remetente, "ContraGolpe");
            mensagem.To.Add(destino);
            mensagem.Subject = "Código de verificação - ContraGolpe";
            mensagem.IsBodyHtml = true;
            mensagem.Body = $@"
                <div style='font-family:Arial,sans-serif;background:#f5f7fb;padding:24px;'>
                    <div style='max-width:520px;margin:auto;background:#ffffff;border-radius:14px;padding:24px;border:1px solid #e5e7eb;'>
                        <h2 style='color:#0f3d5e;margin-top:0;'>ContraGolpe</h2>
                        <p>Olá, {WebUtility.HtmlEncode(nome)}.</p>
                        <p>Use o código abaixo para confirmar seu login:</p>
                        <div style='font-size:32px;font-weight:bold;letter-spacing:8px;color:#f97316;background:#fff7ed;border-radius:12px;padding:16px;text-align:center;'>
                            {codigo}
                        </div>
                        <p style='margin-top:18px;color:#555;'>Esse código expira em {ValidadeCodigoMinutos} minutos.</p>
                        <p style='color:#777;font-size:13px;'>Se você não tentou entrar no ContraGolpe, ignore este e-mail.</p>
                    </div>
                </div>";

            using var cliente = new SmtpClient(host, porta);
            cliente.EnableSsl = true;
            cliente.Timeout = 15000;
            cliente.Credentials = new NetworkCredential(remetente, senha);
            await cliente.SendMailAsync(mensagem);
        }
    }
}
