﻿using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    public class ChatController : Controller
    {
        private const string ChaveHistorico = "ChatHistorico";
        private const int MaxTurnos = 12;          // últimas 12 mensagens enviadas à IA
        private const int MaxCaracteres = 1000;    // por mensagem do usuário

        private readonly IClaudeService _claude;
        private readonly IChatbotService _chatbot;

        public ChatController(IClaudeService claude, IChatbotService chatbot)
        {
            _claude = claude;
            _chatbot = chatbot;
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (HttpContext.Session.GetInt32("UsuarioId") == null)
            {
                TempData["MensagemErro"] = "Faça login para conversar com o assistente de IA.";
                return RedirectToAction("Login", "Usuario");
            }

            ViewBag.IaDisponivel = _claude.Configurado;
            return View(LerHistorico());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("ia")]
        public async Task<IActionResult> Enviar([FromBody] ChatRequest pedido, CancellationToken ct)
        {
            if (HttpContext.Session.GetInt32("UsuarioId") == null)
                return StatusCode(401, new { erro = "Faça login para conversar com o assistente." });

            var texto = (pedido?.Mensagem ?? "").Trim();
            if (texto.Length == 0)
                return BadRequest(new { erro = "Digite uma mensagem." });
            if (texto.Length > MaxCaracteres)
                return BadRequest(new { erro = $"A mensagem pode ter no máximo {MaxCaracteres} caracteres." });

            var historico = LerHistorico();
            historico.Add(new ChatTurn { Role = "user", Content = texto });

            // Sem chave da API: responde com o assistente rápido (respostas prontas) em vez de bloquear o chat.
            if (!_claude.Configurado)
            {
                var conversa = historico
                    .Skip(Math.Max(0, historico.Count - MaxTurnos))
                    .Select(t => new ChatMensagem { Papel = t.Role, Texto = t.Content })
                    .ToList();

                var pronta = await _chatbot.ResponderAsync(conversa);

                historico.Add(new ChatTurn { Role = "assistant", Content = pronta.Texto });
                SalvarHistorico(historico);

                return Json(new { resposta = pronta.Texto });
            }

            // A API exige começar com "user": descarta turnos antigos até isso valer
            var enviados = historico.Skip(Math.Max(0, historico.Count - MaxTurnos)).ToList();
            while (enviados.Count > 0 && enviados[0].Role != "user")
                enviados.RemoveAt(0);

            try
            {
                var resposta = await _claude.ConversarAsync(enviados, ct);

                historico.Add(new ChatTurn { Role = "assistant", Content = resposta });
                SalvarHistorico(historico);

                return Json(new { resposta });
            }
            catch (ServicoIAException ex)
            {
                // Não guarda o turno do usuário se a IA falhou
                return StatusCode(502, new { erro = ex.Message });
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Limpar()
        {
            HttpContext.Session.Remove(ChaveHistorico);
            return RedirectToAction("Index");
        }

        private List<ChatTurn> LerHistorico()
        {
            var json = HttpContext.Session.GetString(ChaveHistorico);
            if (string.IsNullOrEmpty(json))
                return new List<ChatTurn>();

            try
            {
                return JsonSerializer.Deserialize<List<ChatTurn>>(json) ?? new List<ChatTurn>();
            }
            catch (JsonException)
            {
                return new List<ChatTurn>();
            }
        }

        private void SalvarHistorico(List<ChatTurn> historico)
        {
            var recentes = historico.Skip(Math.Max(0, historico.Count - MaxTurnos)).ToList();
            HttpContext.Session.SetString(ChaveHistorico, JsonSerializer.Serialize(recentes));
        }
    }
}
