using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Services;

namespace WebApplication1.Controllers
{
    public class AnaliseController : Controller
    {
        private const long TamanhoMaximoImagem = 3 * 1024 * 1024; // 3 MB

        private readonly IAnalisadorGolpeService _analisador;
        private readonly AppDbContext _context;
        private readonly IClaudeService _claude;
        private readonly IVerificadorLinksService _links;

        public AnaliseController(
            IAnalisadorGolpeService analisador,
            AppDbContext context,
            IClaudeService claude,
            IVerificadorLinksService links)
        {
            _analisador = analisador;
            _context = context;
            _claude = claude;
            _links = links;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(NovoModelo(new AnaliseViewModel()));
        }

        // Análise por regras (sempre) + verificação de links + orientação com IA (se pedida)
        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("ia")]
        public async Task<IActionResult> Index(AnaliseViewModel modelo, CancellationToken ct)
        {
            // Os campos de saída não vêm do formulário
            modelo.Resultado = null;
            modelo.Links = new List<ResultadoLink>();
            modelo.Orientacao = null;
            modelo.ErroIA = null;
            modelo.DenunciasSemelhantes = new List<Denuncia>();
            modelo.ImagemResultado = null;
            modelo.ErroImagem = null;
            NovoModelo(modelo);

            if (!ModelState.IsValid)
            {
                return View(modelo);
            }

            modelo.Resultado = _analisador.Analisar(modelo.Mensagem);

            // 1) Verificação real dos links em serviço externo (Google Safe Browsing)
            var links = _links.ExtrairLinks(modelo.Mensagem);
            if (links.Count > 0)
            {
                modelo.Links = await _links.VerificarAsync(links, ct);

                // Link marcado como perigoso eleva o risco, independentemente das regras
                if (modelo.Links.Any(l => l.Status == StatusLink.Perigoso))
                {
                    modelo.Resultado.Sinais.Add(new SinalDetectado
                    {
                        Descricao = "O Google Safe Browsing marcou um dos links como perigoso",
                        Pontos = 60
                    });
                    modelo.Resultado.Pontuacao = Math.Min(100, modelo.Resultado.Pontuacao + 60);
                    modelo.Resultado.Nivel = NivelRisco.Alto;
                }
            }

            // 2) Orientação personalizada com IA generativa (exige login: o recurso tem custo)
            if (modelo.UsarIA)
            {
                if (!modelo.UsuarioLogado)
                {
                    modelo.ErroIA = "Entre na sua conta para receber a orientação personalizada com IA.";
                }
                else if (!_claude.Configurado)
                {
                    modelo.ErroIA = "O recurso de IA ainda não foi configurado neste servidor.";
                }
                else
                {
                    try
                    {
                        modelo.Orientacao = await _claude.OrientarAsync(modelo.Mensagem, modelo.Resultado, modelo.Situacao, ct);
                    }
                    catch (ServicoIAException ex)
                    {
                        modelo.ErroIA = ex.Message;
                    }
                }
            }

            // 3) Liga a análise ao banco: denúncias reais do mesmo tipo
            var tipo = modelo.Resultado.TipoProvavel;
            if (tipo != "Não identificado")
            {
                var termo = $"%{tipo}%";
                modelo.DenunciasSemelhantes = await _context.Denuncias
                    .Where(d => EF.Functions.Like(d.TipoGolpe, termo) ||
                                EF.Functions.Like(d.Categoria, termo))
                    .OrderByDescending(d => d.DataDenuncia)
                    .Take(5)
                    .ToListAsync(ct);
            }

            return View(modelo);
        }

        // Análise de imagens e capturas de tela (visão do Gemini)
        [HttpPost]
        [ValidateAntiForgeryToken]
        [EnableRateLimiting("ia")]
        public async Task<IActionResult> AnalisarImagem(IFormFile? imagem, string? contexto, CancellationToken ct)
        {
            if (HttpContext.Session.GetInt32("UsuarioId") == null)
            {
                TempData["MensagemErro"] = "Faça login para analisar imagens com IA.";
                return RedirectToAction("Login", "Usuario");
            }

            var modelo = NovoModelo(new AnaliseViewModel());

            if (!_claude.Configurado)
            {
                modelo.ErroImagem = "O recurso de IA ainda não foi configurado neste servidor.";
                return View("Index", modelo);
            }

            if (imagem == null || imagem.Length == 0)
            {
                modelo.ErroImagem = "Selecione uma imagem ou captura de tela.";
                return View("Index", modelo);
            }

            if (imagem.Length > TamanhoMaximoImagem)
            {
                modelo.ErroImagem = "A imagem deve ter no máximo 3 MB.";
                return View("Index", modelo);
            }

            byte[] bytes;
            using (var ms = new MemoryStream())
            {
                await imagem.CopyToAsync(ms, ct);
                bytes = ms.ToArray();
            }

            var mediaType = DetectarTipoImagem(bytes);
            if (mediaType == null)
            {
                modelo.ErroImagem = "Formato não suportado. Use JPG, PNG, WEBP ou GIF.";
                return View("Index", modelo);
            }

            if (!string.IsNullOrWhiteSpace(contexto) && contexto.Length > 500)
                contexto = contexto[..500];

            try
            {
                modelo.ImagemResultado = await _claude.AnalisarImagemAsync(bytes, mediaType, contexto, ct);
            }
            catch (ServicoIAException ex)
            {
                modelo.ErroImagem = ex.Message;
            }

            return View("Index", modelo);
        }

        private AnaliseViewModel NovoModelo(AnaliseViewModel modelo)
        {
            modelo.IaDisponivel = _claude.Configurado;
            modelo.LinksDisponivel = _links.Configurado;
            modelo.UsuarioLogado = HttpContext.Session.GetInt32("UsuarioId") != null;
            return modelo;
        }

        // Identifica o tipo pelo conteúdo real do arquivo (não pela extensão).
        private static string? DetectarTipoImagem(byte[] b)
        {
            if (b.Length < 12) return null;

            if (b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) return "image/jpeg";

            if (b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47 &&
                b[4] == 0x0D && b[5] == 0x0A && b[6] == 0x1A && b[7] == 0x0A) return "image/png";

            if (b[0] == 0x47 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x38) return "image/gif";

            if (b[0] == 0x52 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x46 &&
                b[8] == 0x57 && b[9] == 0x45 && b[10] == 0x42 && b[11] == 0x50) return "image/webp";

            return null;
        }
    }
}
