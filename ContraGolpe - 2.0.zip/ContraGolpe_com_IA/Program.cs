using System.Threading.RateLimiting;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using WebApplication1.Data;
using WebApplication1.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// IA simples: analisador de mensagens suspeitas
builder.Services.AddScoped<IAnalisadorGolpeService, AnalisadorGolpeService>();

// Assistente rápido (respostas prontas, sem IA generativa)
builder.Services.AddScoped<IChatbotService, ChatbotService>();

// O JavaScript dos chats envia o token anti-CSRF neste cabeçalho
builder.Services.AddAntiforgery(options => options.HeaderName = "RequestVerificationToken");

// IA generativa (Google Gemini) e verificação de links (Google Safe Browsing).
// As chaves ficam em user-secrets (Gemini:ApiKey e SafeBrowsing:ApiKey). Sem chave, os recursos ficam desativados.
builder.Services.AddHttpClient<IClaudeService, GeminiService>(c => c.Timeout = TimeSpan.FromSeconds(60));
builder.Services.AddHttpClient<IVerificadorLinksService, VerificadorLinksService>(c => c.Timeout = TimeSpan.FromSeconds(10));

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Fotos de perfil: pasta fora do projeto (padrão: %LOCALAPPDATA%\ContraGolpe\avatars).
// Pode ser trocada com "Avatars:Pasta" no appsettings.json ou nos user-secrets.
var pastaAvatares = builder.Configuration["Avatars:Pasta"];
if (string.IsNullOrWhiteSpace(pastaAvatares))
{
    var baseLocal = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
    pastaAvatares = string.IsNullOrWhiteSpace(baseLocal)
        ? Path.Combine(builder.Environment.ContentRootPath, "App_Data", "avatars")
        : Path.Combine(baseLocal, "ContraGolpe", "avatars");
}
Directory.CreateDirectory(pastaAvatares);
builder.Services.AddSingleton(new ArmazenamentoAvatares(pastaAvatares));

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// Limita tentativas em login, registro e verificação do código (por IP): 10 por minuto.
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("autenticacao", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            httpContext.Connection.RemoteIpAddress?.ToString() ?? "desconhecido",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));

    // Recursos de IA têm custo: 10 chamadas por minuto por IP.
    options.AddPolicy("ia", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            httpContext.Connection.RemoteIpAddress?.ToString() ?? "desconhecido",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));

    // Assistente rápido: 20 mensagens por minuto por IP
    options.AddPolicy("chat", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            httpContext.Connection.RemoteIpAddress?.ToString() ?? "desconhecido",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 20,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));
});

builder.WebHost.UseUrls("http://0.0.0.0:5135");

var app = builder.Build();

// Cria o banco (FinalDb) e aplica as migrations sozinho ao iniciar.
// Assim não é preciso rodar Update-Database antes de entrar no site.
// Se o SQL Server/LocalDB não estiver disponível, o site ainda abre e o erro aparece no console.
using (var scope = app.Services.CreateScope())
{
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    try
    {
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        db.Database.Migrate();
        logger.LogInformation("Banco de dados pronto.");
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Não foi possível criar/atualizar o banco de dados. Confira a ConnectionString 'DefaultConnection' e se o SQL Server LocalDB está instalado.");
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

//app.UseHttpsRedirection();

// Necessário para servir arquivos enviados em tempo de execução (ex.: wwwroot/avatars).
// O MapStaticAssets só conhece os arquivos que existiam na hora do build.
app.UseStaticFiles();

// Serve /avatars/... a partir da pasta persistente (as fotos antigas, em wwwroot/avatars, continuam funcionando).
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(pastaAvatares),
    RequestPath = "/avatars"
});

app.UseRouting();

app.UseRateLimiter();
app.UseSession();
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
