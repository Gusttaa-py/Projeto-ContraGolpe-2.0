# ContraGolpe: correções da revisão geral

## Como testar sem o banco antigo
O banco é criado do zero pelas migrations: no Package Manager Console rode `Update-Database` e o LocalDB cria o `FinalDb` com todas as tabelas. Não precisa do banco original. A tela **Analisar Mensagem** (`/Analise`) funciona mesmo sem dados.

## Segurança
1. **Senha com hash fraco.** Era SHA-256 puro, sem salt. Agora usa PBKDF2 (600 mil iterações, salt aleatório). As contas antigas continuam funcionando e são migradas sozinhas no próximo login. Não precisa de migration.
2. **Código 2FA sem limite de tentativas.** Agora são no máximo 5 tentativas, depois é preciso fazer login de novo. A comparação é em tempo constante, o código vai de 100000 a 999999 e o reenvio tem intervalo de 30 s.
3. **Força bruta.** Login, registro, verificação e reenvio limitados a 10 requisições por minuto por IP (`AddRateLimiter` no Program.cs).
4. **Excluir denúncia sem login.** Qualquer pessoa conseguia apagar denúncias. Agora exige login (o botão só aparece para quem está logado).
5. **Overposting.** O formulário de denúncia aceitava `Id` e `DataDenuncia` enviados à mão, o que podia causar erro 500. Agora só aceita os campos do formulário e a data é definida no servidor.
6. **Upload de avatar.** Além da extensão, confere o conteúdo real do arquivo (JPEG/PNG/WEBP).
7. **Busca.** Os caracteres `%`, `_` e `[` digitados pelo usuário agora são tratados como texto.
8. **Senha SMTP.** O csproj ganhou `UserSecretsId`. Use `dotnet user-secrets set "Smtp:Password" "sua-senha-de-app"` em vez de gravar a senha no appsettings.json. O placeholder `COLOQUE_...` é reconhecido como "não configurado".

## Erros de lógica
- **Avatar não aparecia.** `MapStaticAssets` não serve arquivos enviados depois do build. Foi adicionado `UseStaticFiles()`.
- **Tema e modo daltônico se perdiam** a cada troca de página. Agora ficam salvos no navegador. O ícone do tema também estava invertido.
- **Cadastro:** e-mail sem validação de formato e sem normalização; nome e e-mail grandes demais estouravam o banco; dois cadastros simultâneos com o mesmo e-mail davam erro. Nome e e-mail digitados agora são mantidos quando há erro (login e cadastro).
- Falha de SMTP deixava o 2FA pendente na sessão. Agora limpa e registra o erro no log.
- Data do perfil saía em inglês dependendo do servidor. Agora sai em pt-BR.
- Busca agora também procura na descrição (a tela promete "palavras-chave").
- Validação de tamanho dos campos da denúncia (as colunas do banco não têm limite).

## HTML e acessibilidade
- Havia `<main>` dentro de `<main>` e `id="conteudo"` repetido em várias páginas, e o "pular para o conteúdo" tinha duas versões. Agora existe um único `<main id="conteudo">` no layout.
- O `<title>` era sempre "ContraGolpe". Agora usa o título de cada página.
- A tela Excluir estava com visual Bootstrap solto. Foi refeita no padrão do sistema.
- A página de erro estava em inglês e mostrava texto de "Development Mode". Foi refeita em português.
- `localStorage` protegido com try/catch (modo privado bloqueia).

## Novo
- **Analisar Mensagem** (IA baseada em regras ponderadas), no menu: `/Analise`.

## Exclusão restrita ao autor (nova migration)
- A denúncia agora guarda quem a registrou (`UsuarioId`). Só o autor ou um administrador vê o botão Excluir e consegue excluir (o servidor também confere).
- Se a pessoa marcar "enviar como anônimo" (nome vazio), a denúncia **não** é vinculada à conta, para manter o anonimato. Só um administrador consegue excluí-la.
- As denúncias antigas não têm autor, então só um administrador exclui.
- **Administrador:** coloque o e-mail em `appsettings.json`, em `"Admin": { "Emails": [ "seu@email.com" ] }`, e faça login de novo.
- **Para aplicar no banco:** no Package Manager Console, `Update-Database` (ou `dotnet ef database update`). Ela só adiciona a coluna `UsuarioId` (nula) na tabela `Denuncias`, sem apagar dados.

## Assistente rápido (chatbot simples) em `/Chatbot`
- Responde por palavras-chave sobre Pix, WhatsApp, boleto, links falsos, falso prêmio, falsa central, "fui vítima" e dicas de segurança. Se o texto parecer suspeito, usa o analisador de mensagens e mostra o risco.
- **Não precisa de login, de internet nem de chave de API**, então dá para testar de imediato.
- O histórico fica só na tela do navegador, e o servidor limita 20 mensagens por minuto por IP.
- Arquivos: `Services/ChatbotService.cs`, `Controllers/ChatbotController.cs`, `Views/Chatbot/Index.cshtml` (classes CSS `bot-*`).

## Já existia no projeto (não foi feito por mim)
O projeto já tinha uma IA generativa com conversa livre: `ChatController`, `ClaudeService`, `VerificadorLinksService`, `Views/Chat` (menu "Assistente IA") e a ação `Classificar` no `DenunciaController`. Conferi que compilam, mas não revisei a lógica em detalhe. Elas dependem de `Anthropic:ApiKey` (e `SafeBrowsing:ApiKey`), que devem ficar em user-secrets: `dotnet user-secrets set "Anthropic:ApiKey" "sua-chave"`. Sem chave, o "Assistente IA" mostra "ainda não foi configurado" e o "Assistente rápido" continua funcionando.
- Correção minha: o `appsettings.json` tinha o bloco `"Anthropic"` duplicado, o que impede o .NET de iniciar. Agora existe um só.

## Campo de imagem removido
- O campo "Imagem (opcional)" do formulário de denúncia não enviava nada ao servidor (era só visual). Foi removido para não enganar o usuário. Se quiser o upload de verdade, é preciso mais uma coluna no banco (migration).

## Não alterado (decisão sua)
- Logout é por link (GET). Funciona, mas o ideal é um botão POST.
- Não consegui compilar o site inteiro nem abrir as telas (sem acesso ao NuGet): os controllers foram compilados com stubs do EF Core, o analisador e o hash foram testados, e as views foram revisadas à mão. Rode uma vez no Visual Studio e me avise se aparecer erro.

## Correção: não conseguia entrar no site
- **Banco não existia.** O site nunca criava o banco, então login/cadastro/denúncias davam erro. Agora o `Program.cs` aplica as migrations sozinho ao iniciar (cria o `FinalDb` no LocalDB). Não precisa mais rodar `Update-Database`. Se o SQL Server LocalDB não estiver instalado, o site abre mesmo assim e o erro aparece no console.
- **Login travava no código por e-mail.** O login exige código 2FA por e-mail, mas a senha SMTP está como `COLOQUE_SUA_SENHA_AQUI`, então o envio sempre falhava. Agora, **somente em modo Development** e com SMTP não configurado, o código aparece na própria tela de verificação (e no console). Em produção continua exigindo o SMTP.
- Para receber o código por e-mail de verdade: `dotnet user-secrets set "Smtp:Password" "sua-senha-de-app-do-gmail"`.
- Rode pelo perfil **http** (o padrão). O site escuta em `http://localhost:5135`; o perfil `https` abre a porta 7051, que o `UseUrls` do Program.cs não ativa.

## Assistente IA sem chave de API
- Antes, sem `Anthropic:ApiKey` o campo de texto do "Assistente IA" ficava desativado. Agora ele fica liberado e, sem chave, responde com o assistente rápido (respostas prontas). Com a chave configurada, volta a usar a IA do Claude automaticamente.

## IA agora usa o Google Gemini (no lugar da Anthropic)
- `Services/ClaudeService.cs` agora contém o `GeminiService`, que chama a API `generateContent` do Gemini. A interface continua `IClaudeService` só para não mexer nos controllers.
- Chave: `Gemini:ApiKey` (pegue grátis em https://aistudio.google.com, "Get API key"). Modelo: `Gemini:Model` (padrão `gemini-2.5-flash-lite`; se der "modelo não encontrado", troque por outro da lista do AI Studio).
- Guarde a chave em user-secrets ou no `appsettings.Development.json`, nunca no `appsettings.json`.
- No plano gratuito o Google pode usar o conteúdo enviado para melhorar seus produtos: não envie dados reais de pessoas.

## Novos golpes e link do B.O.
- **Tipos de Golpes:** a tabela ganhou 13 golpes atuais (investimento/cripto/apostas falsas, emprego falso, golpe do amor, voz clonada e deepfake, QR Code falso, falsa multa/pedágio, falso motoboy, falso INSS/consignado, falsa renegociação de dívida, falso comprador, vaquinha falsa, falso sequestro e falso advogado).
- **Novas categorias** no formulário de denúncia e na sugestão por IA: Investimento Falso, Emprego Falso, Golpe do Amor e Voz/Vídeo Falso (IA).
- **Assistente rápido** responde sobre os golpes novos (amor, voz clonada/IA, QR Code, multa/pedágio, INSS/consignado, sequestro/advogado e vaquinha).
- **Depois de registrar a denúncia**, a pessoa vai para a tela `Denuncia/Registrada`, com um botão para registrar o B.O. online. O B.O. online é feito pela **Polícia Civil** do estado (a PM não registra). O link padrão é a Delegacia Eletrônica de SP e pode ser trocado em `appsettings.json > BoletimOcorrencia:Url`.

## Logo e acessibilidade
- **Logo preta:** o arquivo `logo-navbar-transparente.png` tinha fundo preto de verdade (não era transparente). Gerei uma versão realmente transparente e recortada, e uma versão clara (`logo-navbar-escuro.png`) que aparece automaticamente no tema escuro e no alto contraste.
- **Barra de acessibilidade:**
  - Botões de tema e daltônico estavam ovais; agora são redondos (44x44).
  - Textos de 9–10px agora têm tamanho legível e escalam com A+/A-. Antes, a maioria do site usava px e quase não mudava de tamanho.
  - Alto contraste: o texto dos botões ficava preto sobre fundo preto e, no tema claro, regras antigas forçavam texto escuro sobre fundo preto. Corrigido.
  - Botões ligados (tema escuro, daltônico, alto contraste) ficam destacados e anunciam o estado para leitores de tela (`aria-pressed` e aviso por voz).
  - Leitura em voz alta: lê em trechos curtos (antes parava no meio de textos longos em alguns navegadores), escolhe voz pt-BR, não duplica a leitura ao clicar de novo e avisa se o navegador não suporta.
  - Preferências (tema, contraste, daltônico, tamanho da letra) são aplicadas antes de a página aparecer, sem "piscar".
  - A+/A- mudam de 2 em 2 pixels, de 14 a 24.

## Verificação de e-mail 1 vez por mês
- Antes, o código de 6 números era pedido em **todo login**. Agora, depois de confirmar o código, o navegador guarda um cookie protegido (criptografado e assinado) por **30 dias**. Nesse período o login só pede e-mail e senha.
- Passados os 30 dias, o código volta a ser pedido e a contagem recomeça.
- Na tela do código há a opção "Não pedir o código neste navegador por 30 dias" (marcada por padrão). Quem desmarcar (computador público) recebe o código em todo login.
- O cookie vale só para aquele navegador e aquela conta. Outro navegador ou aparelho, cookies apagados, cookie adulterado ou troca de senha pedem o código de novo. Sair da conta (logout) não apaga a verificação.
- Para mudar o prazo, altere `DiasVerificacaoEmail` em `Controllers/UsuarioController.cs`. Não há mudança no banco de dados.
